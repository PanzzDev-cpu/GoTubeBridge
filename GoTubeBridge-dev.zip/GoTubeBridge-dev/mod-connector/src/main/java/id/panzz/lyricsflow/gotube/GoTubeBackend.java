package id.panzz.lyricsflow.gotube;

import dev.lyricsflow.config.LFConfig;
import dev.lyricsflow.media.MediaBackend;
import dev.lyricsflow.media.Track;
import java.io.IOException;

/** Prototype adapter. Add to the mod source/build and select it from a client mixin on Android. */
public final class GoTubeBackend implements MediaBackend {
    private final GoTubeBridgeClient bridge = new GoTubeBridgeClient();
    private volatile String status = "GoTube: disconnected";
    private volatile byte[] cover;

    @Override public Track poll(LFConfig.Source source) {
        try {
            GoTubeBridgeClient.Snapshot s = bridge.poll();
            if (!s.available() || s.title().isBlank()) {
                status = "GoTube: waiting for playback";
                return null;
            }
            status = "GoTube: " + (s.playing() ? "playing" : "paused");
            return new Track(s.title(), s.artist(), s.album(), s.durationMs(),
                    s.positionMs(), s.playing(), "GoTube", System.nanoTime());
        } catch (IOException ex) {
            status = "GoTube Bridge unavailable";
            return null;
        }
    }
    @Override public byte[] cover() { return cover; }
    @Override public void playPause() { command(0); }
    @Override public void next() { command(1); }
    @Override public void previous() { command(2); }
    @Override public void seek(long positionMs) {
        try { bridge.seek(positionMs); } catch (IOException ex) { status = "GoTube seek failed"; }
    }
    private void command(int c) {
        try {
            if (c == 0) bridge.playPause();
            else if (c == 1) bridge.next();
            else bridge.previous();
        } catch (IOException ex) { status = "GoTube control failed"; }
    }
    @Override public String statusKey() { return status; }
    @Override public boolean available() {
        try { return bridge.poll().available(); }
        catch (IOException ex) { return false; }
    }
    @Override public void close() { bridge.close(); }
}
