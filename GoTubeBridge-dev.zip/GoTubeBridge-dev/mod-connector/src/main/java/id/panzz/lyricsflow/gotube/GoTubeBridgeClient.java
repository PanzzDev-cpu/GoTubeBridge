package id.panzz.lyricsflow.gotube;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

/** Small Java 21 client for the companion Android GoTube Bridge protocol. */
public final class GoTubeBridgeClient implements AutoCloseable {
    public record Snapshot(String title, String artist, String album, long durationMs,
                           long positionMs, boolean playing, boolean available, long sampledAtMs) {}
    private static final String HOST = "127.0.0.1";
    private static final int PORT = 38765;

    public Snapshot poll() throws IOException {
        String json = request("GET", -1);
        return new Snapshot(str(json,"title"), str(json,"artist"), str(json,"album"),
                num(json,"durationMs"), num(json,"positionMs"), bool(json,"playing"),
                bool(json,"available"), num(json,"sampledAtMs"));
    }
    public void playPause() throws IOException { request("PLAY_PAUSE", -1); }
    public void next() throws IOException { request("NEXT", -1); }
    public void previous() throws IOException { request("PREVIOUS", -1); }
    public void seek(long ms) throws IOException { request("SEEK", Math.max(0,ms)); }
    private String request(String cmd, long position) throws IOException {
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(HOST,PORT),350);
            s.setSoTimeout(700);
            BufferedWriter w = new BufferedWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8));
            String body = "{\"cmd\":\""+cmd+"\""+(position >= 0 ? ",\"positionMs\":"+position : "")+"}";
            w.write(body); w.write('\n'); w.flush();
            return new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8)).readLine();
        }
    }
    // Minimal JSON field readers; fields emitted by the bridge are flat primitives/strings.
    private static String str(String j,String k) { String v=field(j,k); if(v==null)return ""; return v.replace("\\\"","\"").replace("\\\\","\\"); }
    private static long num(String j,String k) { try { return Long.parseLong(field(j,k)); } catch(Exception e){return 0;} }
    private static boolean bool(String j,String k) { return "true".equals(field(j,k)); }
    private static String field(String j,String k) { if(j==null)return null; String key="\""+k+"\":"; int i=j.indexOf(key); if(i<0)return null; i+=key.length(); if(i<j.length()&&j.charAt(i)=='\"'){int e=j.indexOf('\"',i+1);return e<0?null:j.substring(i+1,e);} int e=j.indexOf(',',i); if(e<0)e=j.indexOf('}',i); return e<0?null:j.substring(i,e).trim(); }
    @Override public void close() { }
}
