# GoTube Bridge — development source (alpha)

This is a companion Android app source project and a Java connector prototype for LyricsFlow. It is **not yet a ready-to-install APK or a patched LyricsFlow JAR**.

## What it does
- Watches notifications from package `premium.gotube.adblock.utube` only.
- Reads title/artist fallback from the GoTube media notification and richer metadata/playback position from its Android MediaSession token when available.
- Exposes a tiny newline-delimited JSON protocol on `127.0.0.1:38765` only. It does not bind to Wi-Fi/LAN interfaces.
- Supports GET, PLAY_PAUSE, NEXT, PREVIOUS and SEEK.

## Build the Android app
Open this folder in Android Studio (Jellyfish or newer), install Android SDK Platform 35, then build `app` > `assembleDebug`. The build environment used to prepare this source did not contain Android SDK/Gradle, so no APK was compiled here.

## First test on Redmi
1. Install the debug APK built by Android Studio.
2. Open GoTube Bridge and tap **Buka izin akses notifikasi**.
3. Enable notification access for GoTube Bridge. This permission is powerful; Android can expose notifications from other apps to the listener. This prototype deliberately filters and processes only GoTube's package.
4. Start a track in GoTube and keep GoTube Bridge installed/enabled.
5. A local test client can connect to `127.0.0.1:38765` and send `{"cmd":"GET"}` followed by newline.

## Important integration status
The supplied LyricsFlow JAR is a compiled Fabric mod. Its current `MediaManager.backend()` returns a `SmtcBackend` directly, and `LFConfig.Source` has no GoTube enum. Merely adding this connector class to the JAR will not activate it. The next required mod-side work is to add a Fabric mixin/adapter that selects `GoTubeBridgeClient` on Android (preferably only when source is `ANY`, preserving existing desktop backends), maps the snapshot to LyricsFlow's `Track`, and forwards controls. That integration must be compiled against the exact LyricsFlow 2.2 + MC 1.21.11 mappings and tested in Zalith; it is intentionally not represented as completed in this prototype.

## Protocol response
`{"app":"premium.gotube.adblock.utube","title":"...","artist":"...","album":"...","durationMs":355000,"positionMs":2000,"playing":true,"sampledAtMs":...,"available":true}`
