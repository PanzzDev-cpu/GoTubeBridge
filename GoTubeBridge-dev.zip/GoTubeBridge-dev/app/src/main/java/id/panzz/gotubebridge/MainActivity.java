package id.panzz.gotubebridge;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 48, 36, 36);
        TextView title = new TextView(this);
        title.setText("GoTube Bridge · Alpha 0.1\n\nPenghubung metadata GoTube ke mod LyricsFlow melalui localhost saja.");
        title.setTextSize(18);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("Langkah:\n1. Aktifkan akses notifikasi untuk GoTube Bridge.\n2. Putar lagu di GoTube.\n3. Biarkan aplikasi ini terpasang saat Minecraft berjalan.\n\nBridge hanya menerima koneksi dari perangkat sendiri (127.0.0.1:38765).");
        info.setTextSize(15);
        root.addView(info);
        Button settings = new Button(this);
        settings.setText("Buka izin akses notifikasi");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        root.addView(settings);
        setContentView(root);
    }
}
