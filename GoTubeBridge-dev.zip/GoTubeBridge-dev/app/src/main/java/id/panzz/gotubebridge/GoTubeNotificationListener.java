package id.panzz.gotubebridge;

import android.app.Notification;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class GoTubeNotificationListener extends NotificationListenerService {
    private static final String GOTUBE_PACKAGE = "premium.gotube.adblock.utube";
    private static final int PORT = 38765;
    private static volatile GoTubeNotificationListener instance;
    private volatile MediaController controller;
    private volatile String fallbackTitle = "", fallbackArtist = "";
    private volatile boolean running;
    private ExecutorService server;

    @Override public void onListenerConnected() {
        super.onListenerConnected();
        instance = this;
        running = true;
        server = Executors.newSingleThreadExecutor();
        server.execute(this::serve);
        try { for (StatusBarNotification n : getActiveNotifications()) updateFromNotification(n); }
        catch (Exception ignored) { }
    }

    @Override public void onNotificationPosted(StatusBarNotification sbn) { updateFromNotification(sbn); }
    @Override public void onNotificationRemoved(StatusBarNotification sbn) {
        if (GOTUBE_PACKAGE.equals(sbn.getPackageName())) {
            MediaController c = controller;
            if (c != null) { try { c.unregisterCallback(callback); } catch (Exception ignored) { } }
            controller = null;
        }
    }

    private final MediaController.Callback callback = new MediaController.Callback() {
        @Override public void onMetadataChanged(MediaMetadata metadata) { }
        @Override public void onPlaybackStateChanged(PlaybackState state) { }
    };

    private void updateFromNotification(StatusBarNotification sbn) {
        if (!GOTUBE_PACKAGE.equals(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        Bundle e = n.extras;
        CharSequence t = e.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence a = e.getCharSequence(Notification.EXTRA_TEXT);
        fallbackTitle = t == null ? "" : t.toString();
        fallbackArtist = a == null ? "" : a.toString();
        Object token = e.get(Notification.EXTRA_MEDIA_SESSION);
        if (token instanceof MediaSession.Token) {
            try {
                MediaController next = new MediaController(this, (MediaSession.Token) token);
                MediaController old = controller;
                if (old != null) old.unregisterCallback(callback);
                controller = next;
                next.registerCallback(callback);
            } catch (Exception ignored) { }
        }
    }

    private JSONObject snapshot() throws Exception {
        JSONObject o = new JSONObject();
        o.put("app", GOTUBE_PACKAGE);
        MediaController c = controller;
        MediaMetadata m = c == null ? null : c.getMetadata();
        PlaybackState p = c == null ? null : c.getPlaybackState();
        String title = m == null ? fallbackTitle : m.getString(MediaMetadata.METADATA_KEY_TITLE);
        String artist = m == null ? fallbackArtist : m.getString(MediaMetadata.METADATA_KEY_ARTIST);
        long duration = m == null ? 0 : m.getLong(MediaMetadata.METADATA_KEY_DURATION);
        long position = p == null ? 0 : Math.max(0, p.getPosition());
        boolean playing = p != null && p.getState() == PlaybackState.STATE_PLAYING;
        o.put("title", title == null ? "" : title);
        o.put("artist", artist == null ? "" : artist);
        o.put("album", m == null ? "" : safe(m.getString(MediaMetadata.METADATA_KEY_ALBUM)));
        o.put("durationMs", duration);
        o.put("positionMs", position);
        o.put("playing", playing);
        o.put("sampledAtMs", System.currentTimeMillis());
        o.put("available", !((title == null || title.isEmpty()) && fallbackTitle.isEmpty()));
        return o;
    }
    private static String safe(String s) { return s == null ? "" : s; }

    private void serve() {
        try (ServerSocket ss = new ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))) {
            while (running) {
                try (Socket s = ss.accept();
                     BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                     PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true)) {
                    s.setSoTimeout(1500);
                    String line = in.readLine();
                    if (line == null) continue;
                    JSONObject req = new JSONObject(line);
                    String cmd = req.optString("cmd", "GET");
                    MediaController c = controller;
                    if (c != null) {
                        switch (cmd) {
                            case "PLAY_PAUSE": c.getTransportControls().playPause(); break;
                            case "NEXT": c.getTransportControls().skipToNext(); break;
                            case "PREVIOUS": c.getTransportControls().skipToPrevious(); break;
                            case "SEEK": c.getTransportControls().seekTo(Math.max(0, req.optLong("positionMs", 0))); break;
                        }
                    }
                    out.println(snapshot().toString());
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
    }

    @Override public void onListenerDisconnected() {
        running = false;
        if (server != null) server.shutdownNow();
        instance = null;
        super.onListenerDisconnected();
    }
}
